import shared.UI;
import shared.Input;
import shared.Context;
import shared.NavAction;
import auth.AuthRepository;
import auth.AuthService;
import auth.AuthMain;
import admin.AdminRepository;
import admin.AdminService;
import admin.AdminMain;
import customer.CustomerRepository;
import customer.CustomerService;
import customer.CustomerMain;
import eventManager.EventManagerService;
import eventManager.EventManagerMain;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static UI ui = new UI();
    static Input input = new Input(sc, ui);

    // Dependencies
    static AuthRepository authRepo = new AuthRepository();
    static AdminRepository adminRepo = new AdminRepository();
    static CustomerRepository customerRepo = new CustomerRepository();

    static AuthService authService = new AuthService(authRepo);
    static AdminService adminService = new AdminService(adminRepo, customerRepo);
    static CustomerService customerService = new CustomerService(customerRepo, adminRepo);
    static EventManagerService eventManagerService = new EventManagerService(adminRepo, customerRepo);

    static AuthMain authMain = new AuthMain(authService);
    static AdminMain adminMain = new AdminMain(adminService);

    public static void main(String[] args) {
        // Global UI State Configuration
        Context.ui = ui;
        Context.input = input;
        Context.guestMenuRoute = authMain::guestMenu;
        Context.userMenuRoute = Main::userMenu;

        // Seed core system data across domains
        adminService.seedData();
        customerService.seed();

        Context.navigate(authMain::guestMenu);
        while (true) {
            if (Context.screenStack.isEmpty()) {
                Context.navigate(authMain::guestMenu);
            }
            Runnable screen = Context.screenStack.peek();
            screen.run();
        }
    }

    public static void userMenu() {
        ui.clear();
        ui.title("EVENT BOOKING PLATFORM");
        ui.header(Context.current);

        System.out.println("Role : " + Context.current.getAccountType());
        System.out.println();
        System.out.println("1) View Profile");
        
        System.out.println("2) Enter " + Context.current.getAccountType() + " Dashboard");
        
        System.out.println("3) Logout");
        System.out.println("4) Exit");
        System.out.println();

        int c = input.readIntWithNav("Command: ");
        if (c == Integer.MIN_VALUE) {
            if (Context.handleNav(input.getLastNav())) return;
            return;
        }
        
        switch (c) {
            case 1: 
                Context.navigate(authMain::profile); 
                break;
            case 2: 
                String role = Context.current.getAccountType();
                if (role.equalsIgnoreCase("Admin")) {
                    adminMain.startAdmin();
                } else if (role.equalsIgnoreCase("Consumer")) {
                    CustomerMain customerMain = new CustomerMain(customerService, Context.current.getId(), Context.current.getUsername());
                    customerMain.startCustomer();
                } else if (role.equalsIgnoreCase("Organizer")) {
                    EventManagerMain emMain = new EventManagerMain(eventManagerService, Context.current.getId(), Context.current.getUsername());
                    emMain.startOrganizer();
                }
                break;
            case 3: 
                Context.handleNav(NavAction.LOGOUT); 
                break;
            case 4: 
                Context.handleNav(NavAction.EXIT); 
                break;
            default:
                ui.warn("Invalid choice");
                Context.pauseAndStay();
        }
    }
}
