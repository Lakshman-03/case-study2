package shared;

public class ValidationUtils {
    public static boolean isValidEmail(String s) {
        if (s == null) return false;
        s = s.trim();
        if (s.length() < 5) return false;
        int at = s.indexOf('@');
        int dot = s.lastIndexOf('.');
        if (at <= 0) return false;
        if (dot < at + 2) return false;
        if (dot >= s.length() - 1) return false;
        return true;
    }

    public static String maskPasswordObfuscated(String s) {
        if (s == null || s.isEmpty()) return "(empty)";
        final int BULLETS = 10; 
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < BULLETS; i++) sb.append('*');
        return sb.toString();
    }

    public static String passwordStrength(String s) {
        if (s == null) return "Weak";
        int score = 0;
        int len = s.length();
        if (len >= 8) score++;
        if (len >= 12) score++; 
        boolean hasLower = false, hasUpper = false, hasDigit = false, hasSymbol = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLowerCase(c)) hasLower = true;
            else if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else hasSymbol = true;
        }
        if (hasLower && hasUpper) score++;
        if (hasDigit) score++;
        if (hasSymbol) score++;

        if (score <= 2) return "Weak";
        if (score == 3) return "Medium";
        if (score == 4 || score == 5) return "Strong";
        return "Very strong";
    }
}
