package shared;

import auth.User;

public class UI {
    private final int width = 70;
    
    public void clear() { 
        System.out.print("\033[H\033[2J"); 
        System.out.flush(); 
    }
    
    public void title(String t) { 
        String line = repeat("-", width); 
        println(line); 
        println(center("** " + t + " **", width)); 
        println(line); 
    }
    
    public void header(User current) { 
        println("User: " + (current == null ? "Guest" : current.getUsername() + " (" + current.getAccountType() + ")")); 
        println("Shortcuts: :menu  :back  :logout  :help  :exit"); 
        println(repeat("-", width)); 
    }
    
    public void help() { 
        println("\nHelp\n  :menu   - Go to main menu\n  :back   - Go to previous screen\n  :logout - Logout\n  :exit   - Exit application\n  :help   - Show this help\n"); 
    }
    
    public void info(String msg) { println("[i] " + msg); } 
    public void success(String msg) { println("[~] " + msg); } 
    public void warn(String msg) { println("[!] " + msg); } 
    public void error(String msg) { println("[x] " + msg); }
    
    public void tinyWait(String msg) { 
        System.out.print(msg + " "); 
        for (int i = 0; i < 3; i++) { 
            System.out.print("."); 
            sleep(120); 
        } 
        System.out.println(); 
    }
    
    public void prompt(String label) { System.out.print(label); }
    
    public void profileCard(User u) { 
        String top = "+" + repeat("-", 40) + "+"; 
        String pad = "| "; 
        println(top); 
        println(pad + padRight("ID:       " + u.getId(), 38) + "|"); 
        println(pad + padRight("Username: " + u.getUsername(), 38) + "|"); 
        println(pad + padRight("Email:    " + u.getEmail(), 38) + "|"); 
        println(pad + padRight("Role:     " + u.getAccountType(), 38) + "|"); 
        println(top); 
    }
    
    private void println(String s) { System.out.println(s); } 
    private String repeat(String s, int count) { 
        StringBuilder sb = new StringBuilder(); 
        for (int i = 0; i < count; i++) sb.append(s); 
        return sb.toString(); 
    }
    
    private String center(String s, int width) { 
        if (s.length() >= width) return s; 
        int left = (width - s.length()) / 2; 
        return repeat(" ", left) + s; 
    }
    
    private String padRight(String s, int len) { 
        if (s.length() >= len) return s.substring(0, len); 
        StringBuilder sb = new StringBuilder(s); 
        while (sb.length() < len) sb.append(' '); 
        return sb.toString(); 
    }
    
    private void sleep(long ms) { 
        try { Thread.sleep(ms); } catch (InterruptedException ignore) {} 
    }
}
