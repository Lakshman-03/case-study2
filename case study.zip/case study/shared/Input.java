package shared;

import java.util.Scanner;

public class Input {
    private final Scanner sc; 
    private final UI ui;
    private NavAction lastNav = NavAction.NONE;

    public Input(Scanner sc, UI ui) { 
        this.sc = sc; 
        this.ui = ui; 
    }
    
    public String readLine() { return sc.nextLine(); }
    
    public NavAction parseNav(String s) {
        if (s == null) return NavAction.NONE;
        switch (s.trim().toLowerCase()) { 
            case ":menu": return NavAction.MENU; 
            case ":back": return NavAction.BACK; 
            case ":logout": return NavAction.LOGOUT; 
            case ":exit": return NavAction.EXIT; 
            case ":help": return NavAction.HELP; 
            default: return NavAction.NONE; 
        }
    }
    
    public NavAction getLastNav() { return lastNav; }
    
    public int readIntWithNav(String prompt) {
        while (true) {
            ui.prompt(prompt); 
            String s = sc.nextLine().trim(); 
            NavAction n = parseNav(s); 
            if (n != NavAction.NONE) { lastNav = n; return Integer.MIN_VALUE; }
            try { return Integer.parseInt(s); } catch (Exception e) { System.out.println("Please enter a number or a command like :menu"); }
        }
    }
    
    public String readNonEmptyWithNav(String prompt) {
        while (true) {
            ui.prompt(prompt); 
            String s = sc.nextLine(); 
            NavAction n = parseNav(s); 
            if (n != NavAction.NONE) { lastNav = n; return null; }
            if (s != null && s.trim().length() > 0) return s.trim(); 
            System.out.println("Input required or use :menu");
        }
    }
    
    public String readEmailWithNav(String prompt) {
        while (true) {
            ui.prompt(prompt); 
            String s = sc.nextLine(); 
            NavAction n = parseNav(s); 
            if (n != NavAction.NONE) { lastNav = n; return null; }
            if (ValidationUtils.isValidEmail(s)) return s.trim(); 
            System.out.println("Enter a valid email (e.g., name@example.com) or use :menu");
        }
    }
    
    public String readPasswordWithNav(String prompt) {
        while (true) {
            ui.prompt(prompt); 
            java.io.Console console = System.console(); 
            String s;
            if (console != null) { 
                char[] pwd = console.readPassword(); 
                s = (pwd == null) ? "" : new String(pwd); 
            } else { 
                s = sc.nextLine(); 
            }
            NavAction n = parseNav(s); 
            if (n != NavAction.NONE) { lastNav = n; return null; }
            if (s != null && s.trim().length() >= 4) return s; 
            System.out.println("Password must be at least 4 characters or use :menu");
        }
    }
    
    public String readRoleWithNav(String prompt) {
        while (true) {
            ui.prompt(prompt); 
            String s = sc.nextLine().trim(); 
            NavAction n = parseNav(s); 
            if (n != NavAction.NONE) { lastNav = n; return null; }
            if (s.equals("1")) return "Admin"; 
            if (s.equals("2")) return "Organizer"; 
            if (s.equals("3")) return "Consumer"; 
            System.out.println("Choose 1, 2, or 3 or use :menu");
        }
    }
}
