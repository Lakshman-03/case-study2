package shared;

import auth.User;
import java.util.ArrayDeque;
import java.util.Deque;

public class Context {
    public static User current = null;
    public static Deque<Runnable> screenStack = new ArrayDeque<>();
    public static UI ui;
    public static Input input;
    
    public static Runnable guestMenuRoute;
    public static Runnable userMenuRoute;

    public static void navigate(Runnable screen) { 
        screenStack.push(screen); 
    }

    public static void goBack() {
        if (!screenStack.isEmpty()) screenStack.pop();
        if (screenStack.isEmpty() && guestMenuRoute != null) navigate(guestMenuRoute);
    }

    public static boolean handleNav(NavAction n) {
        switch (n) {
            case MENU:
                screenStack.clear();
                navigate(current == null ? guestMenuRoute : userMenuRoute);
                return true;
            case BACK:
                goBack();
                return true;
            case LOGOUT:
                current = null;
                System.out.println();
                ui.info("You have been logged out.");
                screenStack.clear();
                navigate(guestMenuRoute);
                return true;
            case HELP:
                ui.help();
                return false; 
            case EXIT:
                System.out.println("Goodbye!");
                System.exit(0);
                return true;
            case NONE:
            default:
                return false;
        }
    }
    
    public static void pauseAndStay() {
        System.out.println();
        ui.prompt("Press Enter or type a command (e.g., :menu)... ");
        String line = input.readLine();
        NavAction n = input.parseNav(line);
        handleNav(n);
    }

    public static void pauseAndBack() {
        System.out.println();
        ui.prompt("Press Enter to go back or type a command (e.g., :menu)... ");
        String line = input.readLine();
        NavAction n = input.parseNav(line);
        if (!handleNav(n)) {
            goBack();
        }
    }

    public static void pauseAndGoMenu() {
        System.out.println();
        ui.prompt("Press Enter to go to menu or type a command (e.g., :exit)... ");
        String line = input.readLine();
        NavAction n = input.parseNav(line);
        if (!handleNav(n)) {
            screenStack.clear();
            navigate(current == null ? guestMenuRoute : userMenuRoute);
        }
    }
}
