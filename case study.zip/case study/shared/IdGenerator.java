package shared;

public class IdGenerator {
    public static String generate() { 
        return "U" + (System.currentTimeMillis() % 100000) + (int)(Math.random() * 100); 
    }
}
