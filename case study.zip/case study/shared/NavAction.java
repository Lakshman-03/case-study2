package shared;

public enum NavAction { NONE, MENU, BACK, LOGOUT, EXIT, HELP }
