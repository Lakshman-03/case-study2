package auth;

public class User {
    private String id;
    private String username;
    private String password;
    private String accountType;
    private String email;

    public User(String id, String username, String password, String accountType, String email) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.accountType = accountType;
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getAccountType() {
        return accountType;
    }

    public String getEmail() {
        return email;
    }
}
