package auth;

import shared.IdGenerator;

public class AuthService {
    private AuthRepository repository;

    public AuthService(AuthRepository repository) {
        this.repository = repository;
    }

    public boolean emailExists(String email) {
        User[] users = repository.getUsers();
        for (int i = 0; i < repository.getCount(); i++) {
            if (users[i].getEmail().equalsIgnoreCase(email))
                return true;
        }
        return false;
    }

    public User register(String username, String password, String role, String email) {
        if (repository.getCount() >= repository.getUsers().length)
            return null;
        if (emailExists(email))
            return null;
        User u = new User(IdGenerator.generate(), username, password, role, email);
        repository.addUser(u);
        return u;
    }

    public User login(String email, String password) {
        User[] users = repository.getUsers();
        for (int i = 0; i < repository.getCount(); i++) {
            if (users[i].getEmail().equalsIgnoreCase(email) && users[i].getPassword().equals(password)) {
                return users[i];
            }
        }
        return null;
    }
}
