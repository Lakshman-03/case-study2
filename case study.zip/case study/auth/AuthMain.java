package auth;

import shared.Context;
import shared.NavAction;
import shared.ValidationUtils;

public class AuthMain {
    private AuthService service;

    public AuthMain(AuthService service) {
        this.service = service;
    }

    public void guestMenu() {
        Context.ui.clear();
        Context.ui.title("EVENT BOOKING PLATFORM");
        Context.ui.header(Context.current);
        greeting();

        System.out.println("1) Register");
        System.out.println("2) Login");
        System.out.println("3) Exit");
        System.out.println();

        int c = Context.input.readIntWithNav("Command: ");
        if (c == Integer.MIN_VALUE) {
            if (Context.handleNav(Context.input.getLastNav()))
                return;
            return;
        }
        switch (c) {
            case 1:
                Context.navigate(this::register);
                break;
            case 2:
                Context.navigate(this::login);
                break;
            case 3:
                Context.handleNav(NavAction.EXIT);
                break;
            default:
                Context.ui.warn("Invalid choice");
                Context.pauseAndStay();
        }
    }

    public void register() {
        Context.ui.clear();
        Context.ui.title("REGISTER");
        Context.ui.header(Context.current);

        String u = Context.input.readNonEmptyWithNav("Username: ");
        if (u == null && Context.handleNav(Context.input.getLastNav()))
            return;

        String e = Context.input.readEmailWithNav("Email: ");
        if (e == null && Context.handleNav(Context.input.getLastNav()))
            return;

        if (service.emailExists(e)) {
            Context.ui.warn("Email already registered");
            Context.pauseAndBack();
            return;
        }

        String p = Context.input.readPasswordWithNav("Password (min 4 chars): ");
        if (p == null && Context.handleNav(Context.input.getLastNav()))
            return;

        System.out.println();
        System.out.println("Available account types");
        System.out.println("  1) Admin      - Manage system");
        System.out.println("  2) Organizer  - Create/Manage events");
        System.out.println("  3) Consumer   - Browse/Book events");

        String role = Context.input.readRoleWithNav("Role (1-3): ");
        if (role == null && Context.handleNav(Context.input.getLastNav()))
            return;

        while (true) {
            Context.ui.clear();
            Context.ui.title("REGISTER - REVIEW");
            Context.ui.header(Context.current);

            String masked = ValidationUtils.maskPasswordObfuscated(p);
            String strength = ValidationUtils.passwordStrength(p);

            System.out.println("Please review your details:");
            System.out.println();
            System.out.println("  Username : " + u);
            System.out.println("  Email    : " + e);
            System.out.println("  Password : " + masked + "  [strength: " + strength + "]");
            System.out.println("  Role     : " + role);
            System.out.println();
            System.out.println("1) Confirm & Register");
            System.out.println("2) Edit Username");
            System.out.println("3) Edit Email");
            System.out.println("4) Edit Password");
            System.out.println("5) Edit Role");
            System.out.println("6) Cancel (Back)");
            System.out.println();

            int choice = Context.input.readIntWithNav("Choice: ");
            if (choice == Integer.MIN_VALUE) {
                if (Context.handleNav(Context.input.getLastNav()))
                    return;
                continue;
            }

            switch (choice) {
                case 1: {
                    Context.ui.tinyWait("Registering");
                    if (service.emailExists(e)) {
                        Context.ui.warn("Email is already registered. Please change the email before confirming.");
                        Context.pauseAndStay();
                        continue;
                    }
                    User user = service.register(u, p, role, e);
                    if (user == null) {
                        if (service.emailExists(e)) {
                            Context.ui.warn("Email is already registered. Please change the email.");
                        } else {
                            Context.ui.error("Registration failed (capacity may be full).");
                        }
                    } else {
                        Context.ui.success("Registered successfully");
                    }
                    Context.pauseAndGoMenu();
                    return;
                }
                case 2: {
                    String newU = Context.input.readNonEmptyWithNav("New username: ");
                    if (newU == null && Context.handleNav(Context.input.getLastNav()))
                        return;
                    if (newU != null && !newU.trim().isEmpty())
                        u = newU.trim();
                    break;
                }
                case 3: {
                    while (true) {
                        String newE = Context.input.readEmailWithNav("New email: ");
                        if (newE == null && Context.handleNav(Context.input.getLastNav()))
                            return;
                        if (newE == null)
                            break;
                        if (service.emailExists(newE)) {
                            Context.ui.warn("That email is already registered. Try another or use :menu.");
                            continue;
                        }
                        e = newE.trim();
                        break;
                    }
                    break;
                }
                case 4: {
                    String newP = Context.input.readPasswordWithNav("New password (min 4 chars): ");
                    if (newP == null && Context.handleNav(Context.input.getLastNav()))
                        return;
                    if (newP != null && newP.trim().length() >= 4)
                        p = newP;
                    break;
                }
                case 5: {
                    String newRole = Context.input.readRoleWithNav("Role (1-3): ");
                    if (newRole == null && Context.handleNav(Context.input.getLastNav()))
                        return;
                    if (newRole != null)
                        role = newRole;
                    break;
                }
                case 6: {
                    Context.ui.info("Registration cancelled.");
                    Context.pauseAndBack();
                    return;
                }
                default:
                    Context.ui.warn("Invalid choice");
                    Context.pauseAndStay();
            }
        }
    }

    public void login() {
        Context.ui.clear();
        Context.ui.title("LOGIN");
        Context.ui.header(Context.current);

        String e = Context.input.readEmailWithNav("Email: ");
        if (e == null && Context.handleNav(Context.input.getLastNav()))
            return;

        String p = Context.input.readPasswordWithNav("Password: ");
        if (p == null && Context.handleNav(Context.input.getLastNav()))
            return;

        Context.ui.tinyWait("Verifying");
        User found = service.login(e, p);
        if (found == null) {
            Context.ui.error("Invalid email or password");
        } else {
            Context.current = found;
            Context.ui.success("Login successful");
            Context.screenStack.clear();
            Context.navigate(Context.userMenuRoute);
        }
        Context.pauseAndStay();
    }

    public void profile() {
        Context.ui.clear();
        Context.ui.title("PROFILE");
        Context.ui.header(Context.current);
        Context.ui.profileCard(Context.current);
        System.out.println();
        System.out.println("Use :back to return or :menu to jump to main menu.");
        Context.pauseAndBack();
    }

    private void greeting() {
        java.time.LocalTime now = java.time.LocalTime.now();
        String msg;
        if (now.isBefore(java.time.LocalTime.NOON))
            msg = "Good morning";
        else if (now.isBefore(java.time.LocalTime.of(17, 0)))
            msg = "Good afternoon";
        else
            msg = "Good evening";
        System.out.println(msg + "!");
        System.out.println();
    }
}
