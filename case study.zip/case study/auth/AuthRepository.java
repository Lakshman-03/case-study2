package auth;

public class AuthRepository {
    private User[] users = new User[100];
    private int count = 0;

    public User[] getUsers() {
        return users;
    }

    public int getCount() {
        return count;
    }

    public void addUser(User u) {
        users[count++] = u;
    }
}
