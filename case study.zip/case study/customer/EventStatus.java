package customer;

public enum EventStatus { PENDING, APPROVED, CANCELLED }
