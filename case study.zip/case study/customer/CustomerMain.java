package customer;

import admin.Location;
import java.util.ArrayList;
import java.util.Scanner;

public class CustomerMain {
    private CustomerService service;
    private String uId;
    private String uName;

    public CustomerMain(CustomerService service, String uId, String uName) {
        this.service = service;
        this.uId = uId;
        this.uName = uName;
    }

    public void startCustomer() {
        User loggedIn = new User(uId, uName, Role.CONSUMER);
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n========== CONSUMER MENU ==========");
            System.out.println("1) View Approved Events");
            System.out.println("2) Book Tickets");
            System.out.println("3) View My Tickets");
            System.out.println("0) Back to Main Menu");
            System.out.print("Choice: ");

            String ch = sc.nextLine();

            if (ch.equals("1")) {
                ArrayList<Event> list = service.getRepository().findApprovedEvents();
                System.out.println("\nApproved Events:");
                for (Event e : list) {
                    Location loc = service.getAdminLocationById(e.getLocationId());
                    String locName = (loc != null) ? loc.name : "Unknown Location";
                    System.out.println(e.getId() + " - " + e.getTitle() + " | Rs." + e.getPrice() +
                            " | Location: " + locName + " | Remaining: " + service.getRemaining(e));
                }
            } else if (ch.equals("2")) {
                System.out.print("Enter Event ID: ");
                int eid = Integer.parseInt(sc.nextLine());
                System.out.print("Enter Quantity: ");
                int qty = Integer.parseInt(sc.nextLine());

                ArrayList<Coupon> coupons = service.getRepository().findActiveCouponsByUser(loggedIn.getUserId());
                boolean apply = false;

                if (coupons.size() > 0) {
                    System.out.println("You have a coupon of Rs." + coupons.get(0).getValue());
                    System.out.print("Apply coupon? y/n: ");
                    apply = sc.nextLine().equalsIgnoreCase("y");
                }

                Ticket t = service.book(loggedIn.getUserId(), eid, qty, apply);
                if (t != null) System.out.println("\nBooking Successful! Ticket ID: " + t.getId());
                else System.out.println("Booking Failed.");

            } else if (ch.equals("3")) {
                ArrayList<Ticket> my = service.getRepository().findTicketsByUser(loggedIn.getUserId());
                if (my.size() == 0) {
                    System.out.println("No Tickets found.");
                } else {
                    System.out.println("\nYour Tickets:");
                    for (Ticket t : my) {
                        Event e = service.getRepository().findEventById(t.getEventId());
                        System.out.println("Ticket " + t.getId() + " | " + e.getTitle() + " | Qty: " + t.getQuantity() + " | Paid: Rs." + t.getFinalPaid());
                    }
                }
            } else if (ch.equals("0")) {
                return;
            }
        }
    }
}
