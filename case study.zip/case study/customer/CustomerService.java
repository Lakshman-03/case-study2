package customer;

import admin.AdminRepository;
import admin.Location;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class CustomerService {
    private CustomerRepository customerRepo;
    private AdminRepository adminRepo;

    public CustomerService(CustomerRepository customerRepo, AdminRepository adminRepo) {
        this.customerRepo = customerRepo;
        this.adminRepo = adminRepo;
    }

    public CustomerRepository getRepository() {
        return customerRepo;
    }
    
    public Location getAdminLocationById(int locId) {
        return adminRepo.findLocationById(locId);
    }

    public int getRemaining(Event e) {
        ArrayList<Ticket> tickets = customerRepo.findTicketsByEvent(e.getId());
        int booked = 0;
        for (Ticket t : tickets) booked += t.getQuantity();
        
        Location loc = adminRepo.findLocationById(e.getLocationId());
        if (loc == null) return 0;
        int remain = loc.seats - booked;
        return remain < 0 ? 0 : remain;
    }

    public Ticket book(String userId, int eventId, int qty, boolean useCoupon) {
        Event e = customerRepo.findEventById(eventId);
        if (e == null || e.getStatus() != EventStatus.APPROVED) { 
            System.out.println("Invalid or unapproved event."); 
            return null; 
        }
        int remaining = getRemaining(e);
        if (qty > remaining) { 
            System.out.println("Not enough seats."); 
            return null; 
        }
        double gross = e.getPrice() * qty;
        double applied = 0;
        Coupon selected = null;
        if (useCoupon) {
            ArrayList<Coupon> coupons = customerRepo.findActiveCouponsByUser(userId);
            if (coupons.size() > 0) {
                selected = coupons.get(0);
                applied = Math.min(selected.getValue(), gross);
            }
        }
        double finalPaid = gross - applied;
        int ticketId = customerRepo.nextTicketId();
        Ticket ticket = new Ticket(ticketId, userId, eventId, qty, gross, applied, finalPaid, LocalDateTime.now());
        customerRepo.saveTicket(ticket);
        if (selected != null) customerRepo.deactivateCoupon(selected);
        return ticket;
    }

    public void seed() {
        customerRepo.saveLocation(new customer.Location(1, "Green Hall", "MG Road", 100));
        customerRepo.saveEvent(new Event(101, "Tech Talk 2026", 1, "org1", 499, java.time.LocalDate.now().plusDays(7), EventStatus.APPROVED));
        customerRepo.saveCoupon(new Coupon(1, "consumer1", 300, true));
    }
}
