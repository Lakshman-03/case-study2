package customer;

import java.util.ArrayList;

public class CustomerRepository {
    private ArrayList<Location> locations = new ArrayList<>();
    private ArrayList<Event> events = new ArrayList<>();
    private ArrayList<Coupon> coupons = new ArrayList<>();
    private ArrayList<Ticket> tickets = new ArrayList<>();
    private int ticketSeq = 1;

    public int nextTicketId() {
        return ticketSeq++;
    }

    // Locations
    public void saveLocation(Location l) {
        locations.add(l);
    }

    public Location findLocationById(int id) {
        for (Location loc : locations)
            if (loc.getId() == id)
                return loc;
        return null;
    }

    // Events
    public ArrayList<Event> getEvents() {
        return events;
    }

    public void saveEvent(Event e) {
        events.add(e);
    }

    public Event findEventById(int id) {
        for (Event e : events)
            if (e.getId() == id)
                return e;
        return null;
    }

    public ArrayList<Event> findApprovedEvents() {
        ArrayList<Event> result = new ArrayList<>();
        for (Event e : events) {
            if (e.getStatus() == EventStatus.APPROVED)
                result.add(e);
        }
        return result;
    }

    // Coupons
    public ArrayList<Coupon> getCoupons() {
        return coupons;
    }

    public void saveCoupon(Coupon c) {
        coupons.add(c);
    }

    public ArrayList<Coupon> findActiveCouponsByUser(String userId) {
        ArrayList<Coupon> result = new ArrayList<>();
        for (Coupon c : coupons) {
            if (c.isActive() && c.getConsumerUserId().equals(userId))
                result.add(c);
        }
        return result;
    }

    public void deactivateCoupon(Coupon c) {
        c.setActive(false);
    }

    // Tickets
    public void saveTicket(Ticket t) {
        tickets.add(t);
    }

    public ArrayList<Ticket> findTicketsByEvent(int eventId) {
        ArrayList<Ticket> res = new ArrayList<>();
        for (Ticket t : tickets) {
            if (t.getEventId() == eventId)
                res.add(t);
        }
        return res;
    }

    public ArrayList<Ticket> findTicketsByUser(String userId) {
        ArrayList<Ticket> res = new ArrayList<>();
        for (Ticket t : tickets) {
            if (t.getConsumerUserId().equals(userId))
                res.add(t);
        }
        return res;
    }
}
