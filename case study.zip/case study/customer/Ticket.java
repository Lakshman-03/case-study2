package customer;

import java.time.LocalDateTime;

public class Ticket {
    private int id;
    private String consumerUserId;
    private int eventId;
    private int quantity;
    private double grossAmount;
    private double couponApplied;
    private double finalPaid;
    private LocalDateTime purchasedAt;

    public Ticket() {
    }

    public Ticket(int id, String consumerUserId, int eventId, int quantity, double grossAmount, double couponApplied,
            double finalPaid, LocalDateTime purchasedAt) {
        this.id = id;
        this.consumerUserId = consumerUserId;
        this.eventId = eventId;
        this.quantity = quantity;
        this.grossAmount = grossAmount;
        this.couponApplied = couponApplied;
        this.finalPaid = finalPaid;
        this.purchasedAt = purchasedAt;
    }

    public int getId() {
        return id;
    }

    public String getConsumerUserId() {
        return consumerUserId;
    }

    public int getEventId() {
        return eventId;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getGrossAmount() {
        return grossAmount;
    }

    public double getCouponApplied() {
        return couponApplied;
    }

    public double getFinalPaid() {
        return finalPaid;
    }

    public LocalDateTime getPurchasedAt() {
        return purchasedAt;
    }
}
