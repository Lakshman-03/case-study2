package customer;

public class Coupon {
    private int id;
    private String consumerUserId;
    private double value;
    private boolean active;

    public Coupon() {
    }

    public Coupon(int id, String consumerUserId, double value, boolean active) {
        this.id = id;
        this.consumerUserId = consumerUserId;
        this.value = value;
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public String getConsumerUserId() {
        return consumerUserId;
    }

    public double getValue() {
        return value;
    }

    public boolean isActive() {
        return active;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setConsumerUserId(String consumerUserId) {
        this.consumerUserId = consumerUserId;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
