package customer;

import java.time.LocalDate;

public class Event {
    private int id;
    private String title;
    private int locationId;
    private String organizerUserId;
    private double price;
    private LocalDate date;
    private EventStatus status;

    public Event() {
    }

    public Event(int id, String title, int locationId, String organizerUserId, double price, LocalDate date,
            EventStatus status) {
        this.id = id;
        this.title = title;
        this.locationId = locationId;
        this.organizerUserId = organizerUserId;
        this.price = price;
        this.date = date;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public int getLocationId() {
        return locationId;
    }

    public String getOrganizerUserId() {
        return organizerUserId;
    }

    public double getPrice() {
        return price;
    }

    public LocalDate getDate() {
        return date;
    }

    public EventStatus getStatus() {
        return status;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    public void setOrganizerUserId(String organizerUserId) {
        this.organizerUserId = organizerUserId;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public void setStatus(EventStatus status) {
        this.status = status;
    }
}
