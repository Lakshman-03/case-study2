package customer;

public enum Role { ADMIN, ORGANIZER, CONSUMER }
