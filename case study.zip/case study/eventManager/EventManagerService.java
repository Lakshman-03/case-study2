package eventManager;

import admin.AdminRepository;
import admin.LocationRequest;
import customer.CustomerRepository;
import customer.Coupon;
import customer.Event;
import customer.EventStatus;
import customer.Ticket;

import java.time.LocalDate;
import java.util.ArrayList;

public class EventManagerService {
    private AdminRepository adminRepo;
    private CustomerRepository customerRepo;

    public EventManagerService(AdminRepository adminRepo, CustomerRepository customerRepo) {
        this.adminRepo = adminRepo;
        this.customerRepo = customerRepo;
    }

    public CustomerRepository getCustomerRepo() {
        return customerRepo;
    }

    public void createEvent(String title, int locId, int seats, String date, double price, String username, String userId) {
        // 1. Send Request to Admin
        LocationRequest req = new LocationRequest(
                adminRepo.nextRequestId++, locId, username, seats, date, title
        );
        adminRepo.addRequest(req);

        // 2. Register Event in Customer system as PENDING
        Event ev = new Event(
                customerRepo.getEvents().size() + 101, title, locId, userId, price, 
                LocalDate.parse(date), EventStatus.PENDING
        );
        customerRepo.saveEvent(ev);
    }

    public boolean editEvent(int eid, String newTitle, double newPrice, String userId) {
        Event ev = customerRepo.findEventById(eid);
        if (ev == null || !ev.getOrganizerUserId().equals(userId)) {
            return false;
        }
        if (ev.getStatus() == EventStatus.CANCELLED) {
            return false;
        }
        if (newTitle != null && !newTitle.trim().isEmpty()) ev.setTitle(newTitle);
        if (newPrice > 0) ev.setPrice(newPrice);
        return true;
    }

    public boolean cancelEvent(int eid, String userId) {
        Event ev = customerRepo.findEventById(eid);
        if (ev == null || !ev.getOrganizerUserId().equals(userId)) {
            return false;
        }

        ev.setStatus(EventStatus.CANCELLED);
        
        // Generate Compensation Coupons
        ArrayList<Ticket> affectedTickets = customerRepo.findTicketsByEvent(eid);
        for (Ticket t : affectedTickets) {
            Coupon compCoupon = new Coupon(
                    customerRepo.getCoupons().size() + 1, t.getConsumerUserId(), t.getFinalPaid(), true
            );
            customerRepo.saveCoupon(compCoupon);
        }
        return true;
    }
}
