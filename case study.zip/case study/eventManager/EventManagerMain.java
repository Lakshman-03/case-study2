package eventManager;

import customer.Event;
import java.util.Scanner;

public class EventManagerMain {
    private EventManagerService service;
    private String userId;
    private String username;

    public EventManagerMain(EventManagerService service, String userId, String username) {
        this.service = service;
        this.userId = userId;
        this.username = username;
    }

    public void startOrganizer() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n========== ORGANIZER MENU ==========");
            System.out.println("1) Create New Event");
            System.out.println("2) View My Events");
            System.out.println("3) Edit Event Details");
            System.out.println("4) Cancel Event");
            System.out.println("5) Back to Main Menu");
            System.out.print("Choose: ");
            
            String ch = sc.nextLine();
            if (ch.equals("1")) createEvent(sc);
            else if (ch.equals("2")) viewEvents();
            else if (ch.equals("3")) editEvent(sc);
            else if (ch.equals("4")) cancelEvent(sc);
            else if (ch.equals("5")) return;
        }
    }

    private void createEvent(Scanner sc) {
        System.out.println("\n--- Create Event ---");
        System.out.print("Event Title: ");
        String title = sc.nextLine();
        
        System.out.print("Enter Location ID (from Admin locations): ");
        int locId = Integer.parseInt(sc.nextLine());
        
        System.out.print("Requested Seats: ");
        int seats = Integer.parseInt(sc.nextLine());
        
        System.out.print("Event Date (yyyy-MM-dd): ");
        String date = sc.nextLine();
        
        System.out.print("Ticket Price (Rs): ");
        double price = Double.parseDouble(sc.nextLine());

        service.createEvent(title, locId, seats, date, price, username, userId);
        System.out.println("Event created! Request sent to Admin for Location ID: " + locId);
    }

    private void viewEvents() {
        System.out.println("\n--- My Events ---");
        for (Event e : service.getCustomerRepo().getEvents()) {
            if (e.getOrganizerUserId().equals(userId)) {
                System.out.println("ID: " + e.getId() + " | Title: " + e.getTitle() + 
                                   " | Status: " + e.getStatus() + " | Price: Rs." + e.getPrice());
            }
        }
    }

    private void editEvent(Scanner sc) {
        System.out.print("\nEnter Event ID to Edit: ");
        int eid = Integer.parseInt(sc.nextLine());
        
        System.out.print("New Title (leave blank to keep current): ");
        String newTitle = sc.nextLine();

        System.out.print("New Price (enter 0 to keep current): ");
        double newPrice = Double.parseDouble(sc.nextLine());
        
        boolean success = service.editEvent(eid, newTitle, newPrice, userId);
        if (success) {
            System.out.println("Event updated successfully!");
        } else {
            System.out.println("Invalid Event ID, unauthorized, or cancelled.");
        }
    }

    private void cancelEvent(Scanner sc) {
        System.out.print("\nEnter Event ID to Cancel: ");
        int eid = Integer.parseInt(sc.nextLine());
        
        boolean success = service.cancelEvent(eid, userId);
        if (success) {
            System.out.println("Event Cancelled! Compensatory coupons issued.");
        } else {
            System.out.println("Invalid Event ID or unauthorized.");
        }
    }
}
