package admin;

public class LocationRequest {
    public int requestId;
    public int locationId;
    public String manager;
    public int requestedSeats;
    public String eventDate;
    public String note;
    public String status;
    public String decision;

    public LocationRequest(int requestId, int locationId, String manager, int requestedSeats, String eventDate, String note) {
        this.requestId = requestId; 
        this.locationId = locationId; 
        this.manager = manager;
        this.requestedSeats = requestedSeats; 
        this.eventDate = eventDate; 
        this.note = note;
        this.status = "PENDING"; 
        this.decision = "";
    }
}
