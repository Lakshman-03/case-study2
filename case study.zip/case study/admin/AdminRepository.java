package admin;

import java.util.ArrayList;

public class AdminRepository {
    private ArrayList<Location> locations = new ArrayList<>();
    private ArrayList<LocationRequest> requests = new ArrayList<>();

    public int nextLocationId = 1;
    public int nextRequestId = 1;

    public void addLocation(Location loc) {
        locations.add(loc);
    }

    public void addRequest(LocationRequest req) {
        requests.add(req);
    }

    public Location findLocationById(int id) {
        for (Location L : locations)
            if (L.id == id)
                return L;
        return null;
    }

    public LocationRequest findRequestById(int id) {
        for (LocationRequest r : requests)
            if (r.requestId == id)
                return r;
        return null;
    }

    public ArrayList<Location> getLocations() {
        return locations;
    }

    public ArrayList<LocationRequest> getRequests() {
        return requests;
    }
}
