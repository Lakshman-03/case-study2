package admin;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeMap;

public class AdminMain {
    private AdminService service;
    private Scanner sc = new Scanner(System.in);

    public AdminMain(AdminService service) {
        this.service = service;
    }

    public void startAdmin() {
        adminMenu();
    }

    private void adminMenu() {
        while (true) {
            System.out.println("\n========== ADMIN MENU ==========");
            System.out.println("1) Add Location");
            System.out.println("2) View Locations");
            System.out.println("3) Approve / Reject Requests");
            System.out.println("4) Monitor Seat Utilization");
            System.out.println("5) Back to Main Menu");

            int ch = readInt("Choose: ");

            if (ch == 1) addLocation();
            else if (ch == 2) viewLocations();
            else if (ch == 3) manageRequests();
            else if (ch == 4) utilization();
            else if (ch == 5) return;
            else System.out.println("Invalid option.");
        }
    }

    private void addLocation() {
        System.out.println("\n--- Add Location ---");
        String name = readNonEmpty("Location Name: ");
        String addr = readNonEmpty("Address: ");
        String city = readNonEmpty("City: ");
        int seats = readPositive("Total Seats: ");

        service.addLocation(name, addr, city, seats);
        System.out.println("Location Added Successfully!");
    }

    private void viewLocations() {
        System.out.println("\n--- Locations ---");
        ArrayList<Location> LOCATIONS = service.getRepository().getLocations();
        if (LOCATIONS.isEmpty()) {
            System.out.println("No locations found.");
        } else {
            for (Location L : LOCATIONS) {
                String[] bookedDates = service.getBookedDates(L.id);
                if (bookedDates.length == 0) {
                    System.out.println("ID: " + L.id + " | " + L.name + " | " + L.city + " | Seats: " + L.seats + " | AVAILABLE");
                } else {
                    System.out.println("ID: " + L.id + " | " + L.name + " | " + L.city + " | Seats: " + L.seats);
                    System.out.println("Booked On:");
                    for (String d : bookedDates) System.out.println(" - " + d);
                }
                System.out.println("--------------------------------");
            }
        }
    }

    private void manageRequests() {
        System.out.println("\n--- Pending Requests ---");
        ArrayList<LocationRequest> pending = new ArrayList<>();
        for (LocationRequest r : service.getRepository().getRequests())
            if (r.status.equals("PENDING")) pending.add(r);

        if (pending.isEmpty()) {
            System.out.println("No pending requests.");
            return;
        }

        for (LocationRequest r : pending) printRequestLine(r);

        int reqId = readInt("Enter Request ID: ");
        LocationRequest req = service.getRepository().findRequestById(reqId);

        if (req == null || !req.status.equals("PENDING")) {
            System.out.println("Invalid request.");
            return;
        }

        Location loc = service.getRepository().findLocationById(req.locationId);

        System.out.println("\nSelected Request:");
        System.out.println("ReqID: " + req.requestId + " | Location: " + loc.name + " | Manager: " + req.manager +
                " | Requested: " + req.requestedSeats + " | Date: " + req.eventDate);

        int booked = service.totalApprovedOnDate(loc.id, req.eventDate);
        int available = loc.seats - booked;

        System.out.println("Booked on " + req.eventDate + ": " + booked);
        System.out.println("Available: " + available);
        System.out.println("--------------------------------");

        System.out.println("1) Approve");
        System.out.println("2) Reject");
        System.out.println("3) Cancel");

        int ch = readInt("Choose: ");

        if (ch == 1) {
            boolean success = service.approveRequest(req, loc);
            if (!success) {
                System.out.println("Not enough seats available!");
            } else {
                System.out.println("Approved!");
            }
        }
        else if (ch == 2) {
            String reason = readNonEmpty("Rejection Reason: ");
            service.rejectRequest(req, reason);
            System.out.println("Rejected.");
        }
    }

    private void printRequestLine(LocationRequest r) {
        Location L = service.getRepository().findLocationById(r.locationId);
        System.out.println("ReqID: " + r.requestId + " | Location: " + L.name + " | Manager: " + r.manager +
                " | Seats: " + r.requestedSeats + " | Date: " + r.eventDate + " | Status: " + r.status);
    }

    private void utilization() {
        System.out.println("\n--- Seat Utilization (Date-Wise) ---");
        for (Location L : service.getRepository().getLocations()) {
            System.out.println("Location: " + L.name + " | Total: " + L.seats);
            TreeMap<String, Integer> map = new TreeMap<>();
            for (LocationRequest r : service.getRepository().getRequests()) {
                if (r.locationId == L.id && r.status.equals("APPROVED")) {
                    map.put(r.eventDate, map.getOrDefault(r.eventDate, 0) + r.requestedSeats);
                }
            }
            if (map.isEmpty()) {
                System.out.println("No bookings yet.");
            } else {
                for (String d : map.keySet()) {
                    int booked = map.get(d);
                    int rem = L.seats - booked;
                    System.out.println(d + " -> Booked: " + booked + " | Remaining: " + rem);
                }
            }
            System.out.println("-----------------------------------");
        }
    }

    private int readInt(String msg) {
        while (true) {
            try {
                System.out.print(msg);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (Exception e) { System.out.println("Enter valid number."); }
        }
    }

    private String readNonEmpty(String msg) {
        while (true) {
            System.out.print(msg);
            String s = sc.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Required.");
        }
    }

    private int readPositive(String msg) {
        int n;
        do {
            n = readInt(msg);
            if (n <= 0) System.out.println("Enter positive value.");
        } while (n <= 0);
        return n;
    }
}
