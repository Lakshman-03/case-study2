package admin;

public class Location {
    public int id;
    public String name;
    public String address;
    public String city;
    public int seats;

    public Location(int id, String name, String address, String city, int seats) {
        this.id = id; 
        this.name = name; 
        this.address = address; 
        this.city = city; 
        this.seats = seats;
    }
}
