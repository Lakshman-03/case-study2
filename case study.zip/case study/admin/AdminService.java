package admin;

import customer.CustomerRepository;
import customer.Event;
import customer.EventStatus;

import java.util.ArrayList;

public class AdminService {
    private AdminRepository adminRepo;
    private CustomerRepository customerRepo; // To approve consumer events cross-module

    public AdminService(AdminRepository adminRepo, CustomerRepository customerRepo) {
        this.adminRepo = adminRepo;
        this.customerRepo = customerRepo;
    }

    // Exposed repository getter for AdminMain/EventManager to find entity by id easily
    public AdminRepository getRepository() {
        return adminRepo;
    }

    public void addLocation(String name, String addr, String city, int seats) {
        adminRepo.addLocation(new Location(adminRepo.nextLocationId++, name, addr, city, seats));
    }

    public String[] getBookedDates(int locId) {
        ArrayList<String> dates = new ArrayList<>();
        for (LocationRequest r : adminRepo.getRequests())
            if (r.locationId == locId && r.status.equals("APPROVED"))
                dates.add(r.eventDate);
        return dates.toArray(new String[0]);
    }

    public int totalApprovedOnDate(int locId, String date) {
        int sum = 0;
        for (LocationRequest r : adminRepo.getRequests())
            if (r.locationId == locId && r.status.equals("APPROVED") && r.eventDate.equals(date))
                sum += r.requestedSeats;
        return sum;
    }

    public boolean approveRequest(LocationRequest req, Location loc) {
        int booked = totalApprovedOnDate(loc.id, req.eventDate);
        int available = loc.seats - booked;

        if (req.requestedSeats > available) {
            return false;
        }

        req.status = "APPROVED";
        
        // Find matching pending event in Customer system and approve it!
        if (customerRepo != null && customerRepo.getEvents() != null) {
            for(Event ce : customerRepo.getEvents()) {
                if(ce.getTitle().equals(req.note) && ce.getLocationId() == loc.id) {
                    ce.setStatus(EventStatus.APPROVED);
                }
            }
        }
        return true;
    }

    public void rejectRequest(LocationRequest req, String reason) {
        req.status = "REJECTED";
        req.decision = reason;
    }

    public void seedData() {
        addLocation("Marina Convention Hall", "Beach Rd", "Chennai", 500);
        addLocation("T-Nagar Community Centre", "Bazaar St", "Chennai", 200);
    }
}
